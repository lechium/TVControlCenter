#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <TVSystemMenuUI/TVSMButtonViewController.h>
#include "@@CLASSPREFIX@@@@PROJECTNAME@@Module.h"

@implementation @@CLASSPREFIX@@@@PROJECTNAME@@Module

+(long long)buttonStyle {
    return 2;
}

-(id)contentViewController {
    
    TVSMButtonViewController *buttonController = (TVSMButtonViewController*)[super contentViewController];
    [buttonController setTitleText:@"Hello World!"];
    [buttonController setSecondaryText:@"we really out here"];
    NSString *packageFile = [[self bundle] pathForResource:@"Package" ofType:@"png"];
    [buttonController setImage:[UIImage imageWithContentsOfFile:packageFile]];
    //note it is important to utilize something like [[UIImage imageWithContentsOfFile:packageFile] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] to properly support different images for light and dark mode

    return buttonController;
}

-(void)handleAction {

    NSLog(@"handleAction");
    
}

-(BOOL)dismissAfterAction {
    return TRUE;
}

@end
