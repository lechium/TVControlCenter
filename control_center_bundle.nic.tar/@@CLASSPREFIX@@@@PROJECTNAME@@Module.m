#include "@@CLASSPREFIX@@@@PROJECTNAME@@Module.h"

@implementation @@CLASSPREFIX@@@@PROJECTNAME@@Module

-(void)contentModuleViewControllerDidTriggerAction:(id)arg1 {
    
    NSLog(@"did trigger action");
    
}

+(long long)buttonStyle {
    return 2;
}

-(id)contentViewController {
    TVSMButtonViewController *buttonController = [TVSMButtonViewController new];
    [buttonController setTitleText:@"Hello World!"];
    [buttonController setSecondaryText:@"we really out here"];
    [buttonController setStyle:[self buttonStyle]];
    [buttonController setDelegate:self];
    [buttonController setImage:[UIImage imageNamed:@"Package"]];
    NSLog(@"my bundle:%@", [NSBundle mainBundle]);
    //NSString *bundle = [[NSBundle mainBundle] pathForResource:@"Package" ofType:@"png"];
    return buttonController;
}

-(void)handleAction {

    NSLog(@"handleAction");
    
}

-(BOOL)dismissAfterAction {
    return TRUE;
}

@end
